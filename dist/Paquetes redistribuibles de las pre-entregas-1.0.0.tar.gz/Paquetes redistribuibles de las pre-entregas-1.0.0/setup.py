from setuptools import setup

setup(
    name= "Paquetes redistribuibles de las pre-entregas",
    version= "1.0.0",
    description= "Paquetes redistribuibles de python de las pre-entregas",
    author= "Julian Dario Gonzalez",

    packages= ["paquetes"]
)